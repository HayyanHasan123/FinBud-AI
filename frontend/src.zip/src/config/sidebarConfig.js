// Sidebar nav config — Part 2 of the spec. Extracted out of AdminLayout.jsx
// per doc 21's requested file split, so nav items can be edited without
// touching layout code, and so any future component (e.g. a breadcrumb,
// or a settings page listing available sections) can import the same list.
export const ADMIN_NAV_ITEMS = [
  { path: '/admin/dashboard',    label: 'Overview',              icon: 'fa-gauge-high',          roles: ['admin'] },
  { path: '/admin/chat-monitor', label: 'Live Chat Monitor',     icon: 'fa-comments',             roles: ['admin', 'banker'] },
  { path: '/admin/tickets',      label: 'Support Tickets',       icon: 'fa-ticket',               roles: ['admin', 'banker'] },
  { path: '/admin/fraud',        label: 'Fraud Alerts',          icon: 'fa-triangle-exclamation', roles: ['admin'] },
  { path: '/admin/activity',     label: 'User Activity Log',     icon: 'fa-clock-rotate-left',    roles: ['admin'] },
  { path: '/admin/users',        label: 'User Management',       icon: 'fa-users',                roles: ['admin', 'banker'] },
  { path: '/admin/rewards',      label: 'Rewards & Points',      icon: 'fa-gift',                 roles: ['admin'] },
  { path: '/admin/kyc',          label: 'KYC Review',            icon: 'fa-id-card',              roles: ['admin'] },
  { path: '/admin/transactions', label: 'Transaction Oversight', icon: 'fa-money-bill-transfer',  roles: ['admin'] },
  { path: '/admin/fees',         label: 'Fee & Revenue',         icon: 'fa-chart-line',           roles: ['admin'] },
  { path: '/admin/settings',     label: 'Admin Settings',        icon: 'fa-gear',                 roles: ['admin'] },
]